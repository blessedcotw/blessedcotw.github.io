#!/usr/bin/env python3
"""
Sync ProPresenter 7 Songs to SongRepo Cloud Database (Automated Background Scheduler)
======================================================================================
Script non-interaktif khusus untuk jalankan sinkronisasi latar belakang otomatis
(Windows Task Scheduler / macOS launchd / cron) tanpa prompt password.
"""

import os
import sys
import json
import datetime
from pathlib import Path

# Set UTF-8 stdout encoding for Windows
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

# Import helper functions from sync_pro7_to_songrepo
SCRIPT_DIR = Path(__file__).parent.resolve()
sys.path.insert(0, str(SCRIPT_DIR))

try:
    from sync_pro7_to_songrepo import (
        get_default_pro7_library_path,
        decode_pro7_file,
        sync_to_supabase,
        decrypt_service_role_key,
        get_service_role_key,
        DEFAULT_SUPABASE_URL
    )
except ImportError as e:
    print(f"❌ Error: Gagal mengimpor fungsi dari sync_pro7_to_songrepo.py: {e}")
    sys.exit(1)

LOG_FILE = SCRIPT_DIR / "sync_scheduler.log"

def log_message(msg: str):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    formatted = f"[{timestamp}] {msg}"
    print(formatted)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(formatted + "\n")
    except Exception:
        pass

def main():
    log_message("=" * 60)
    log_message("🔄 OTOMASI SINKRONISASI PROPRESENTER 7 (BACKGROUND SCHEDULER)")
    log_message("=" * 60)

    # 1. Tentukan Service Role Key
    service_key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
    if not service_key:
        env_pwd = os.getenv("SUPABASE_DECRYPT_PASSWORD") or os.getenv("DECRYPT_PASSWORD")
        if env_pwd:
            try:
                service_key = decrypt_service_role_key(env_pwd)
                log_message("  ✅ API Key berhasil didekripsi dari environment variable.")
            except Exception as e:
                log_message(f"❌ Gagal mendeskripsi API key dengan kata sandi environment: {e}")
                sys.exit(1)
        elif sys.stdin and sys.stdin.isatty():
            try:
                service_key = get_service_role_key()
            except Exception as e:
                log_message(f"❌ Gagal otentikasi API key: {e}")
                sys.exit(1)
        else:
            log_message("❌ Gagal otentikasi: SUPABASE_SERVICE_ROLE_KEY atau SUPABASE_DECRYPT_PASSWORD belum diatur di environment variable.")
            log_message("💡 Silakan jalankan installer 'python scripts/install_scheduler.py' atau atur environment variable.")
            sys.exit(1)

    # 2. Tentukan Folder Target Library ProPresenter
    target_dir_arg = os.getenv("PRO7_LIBRARY_PATH")
    if len(sys.argv) > 1 and sys.argv[1].strip():
        target_dir_arg = sys.argv[1].strip()

    if target_dir_arg:
        lib_dir = Path(target_dir_arg)
    else:
        lib_dir = get_default_pro7_library_path()

    if not lib_dir.exists():
        log_message(f"❌ Folder ProPresenter '{lib_dir}' tidak ditemukan.")
        sys.exit(1)

    log_message(f"📂 Folder Target Library: {lib_dir}")

    # 3. Pindai Berkas .pro
    pro_files = list(lib_dir.glob("**/*.pro"))
    log_message(f"🔍 Ditemukan {len(pro_files)} file .pro.")

    if not pro_files:
        log_message("⚠️ Tidak ada berkas .pro yang ditemukan.")
        return

    songs_list = []
    for pro_path in pro_files:
        parsed = decode_pro7_file(pro_path)
        if parsed:
            songs_list.append(parsed)

    log_message(f"  ✅ Berhasil mengurai {len(songs_list)} lagu.")

    # 4. Upsert ke Supabase
    try:
        sync_to_supabase(songs_list, service_key=service_key)
        log_message("🎉 Sinkronisasi otomatis selesai dengan sukses.")
    except Exception as e:
        log_message(f"❌ Gagal melakukan sinkronisasi otomatis: {e}")

if __name__ == "__main__":
    main()
